<?php

// set header content-type to application/json

// make pdo connection
// prepare select statement
// execute

// assign result to statement's fetchall indexed by column name

// echo out json encoded result

?>