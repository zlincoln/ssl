<!DOCTYPE HTML>
<html>
<head>
	<title>Project #1: Form Processing</title>
	<link rel="stylesheet" href="css/master.css">
</head>
<body>
	<header>
		<nav class="navbar navbar-default">
			<div class="container">
				<div class="navbar-header">
					<a href="./" class="navbar-brand">SSL International</a>
				</div>
			</div>
		</nav>
	</header>