<?php

	//store db username

	//store db password

	//instantiate pdo object, passing credentials as well as setting host, dbname, and port number

?>