<?php

	//include once 'includes/connection.php' which stores db credentials and instantiates pdo object

	//hydrate variables with postdata

	//use pdo object to prepare an update-where statement with params
	//bind those params to our variables containing postdata

	//execute insertion

?>