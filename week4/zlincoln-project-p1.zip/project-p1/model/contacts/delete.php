<?php

	//include once 'includes/connection.php' which stores db credentials and instantiates pdo object

	//the id of the record to delete should have been passed as a url param, so grab from $_GET array and store that id in a variable

	//use pdo object to prepare a delete statement with params

	//bind that param to our id variable
	
	//execute deletion
	
	//redirect to fruits.php
	
	//kill process

?>